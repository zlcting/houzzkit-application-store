"""Version info for Node-RED integration."""

__version__ = "2.2.0"

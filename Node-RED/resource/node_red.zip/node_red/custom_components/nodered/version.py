"""Version info for Node-RED integration."""

__version__ = "4.0.0"
